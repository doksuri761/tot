import time
import fastapi
from fastapi import staticfiles, Header, Request
from fastapi.responses import HTMLResponse, JSONResponse
import requests
import datetime
from fastapi.templating import Jinja2Templates

app = fastapi.FastAPI()
templates = Jinja2Templates(directory="page")
temp = []
loadtime = 0
port = 8080
host = "http://" + "127.0.0.1"


@app.get('/jid')
def jid():
    temp_jid = requests.post("https://login.yoons.com/TAuth/AccountLogin.jsp",
                             data={"AuthID": "yn5730", "PassWD": "bhh230800*"}).cookies["JSESSIONID"]
    jid = requests.post("http://lms.yoons.com/com/actionLogin.do",
                        data={"AgencyCode": 5730, "TeacherCode": 0, "LMSStatus": 2},
                        cookies={"JSESSIONID": temp_jid}).cookies["JSESSIONID"]
    return JSONResponse({"JSESSIONID": jid})


@app.get("/std")
def std(request: Request):
    global temp, loadtime
    if not temp or time.time() - loadtime > 600:
        data = []
        jid = requests.get(f"{host}:{port}/jid").json()["JSESSIONID"]
        payload = {'channelType': 'HO', 'osType': 'Chrome', 'page': 1, 'blockSize': 10,
                   'date': (datetime.datetime.now() - datetime.timedelta(days=30)).strftime("%Y%m%d"),
                   'date2': datetime.datetime.now().strftime("%Y%m%d"), 's_teacher': 0, 'showdata': 2, 's_InquiryLevel': '',
                   's_book': '', 's_student': '', 'view': '', 'studentname': ''}
        url = "http://lms.yoons.com/schedule/scheduleSearch.json"
        for i in range(1, 8):
            payload["page"] = i
            data.extend(requests.post(url, data=payload, cookies={"JSESSIONID": jid}).json()["resultPageList"])
        temp = data
        loadtime = time.time()
    else:
        data = temp
    return templates.TemplateResponse("index.html", {"request": request, "data": data})



def reservation(mcode, cnt, classno, bookid):
    url = "http://lms.yoons.com/schedule/update_class_status.json"
    body = {'bookid': bookid, 'channelType': 'HO', 'classid': 0, 'kind': 'new', 'mcode': mcode, 'osType': 'Chrome',
            'seq': cnt, 'studentofbookid': classno}
    jid = requests.get(f"{host}:{port}/jid").json()["JSESSIONID"]
    result = requests.post(url, data=body, cookies={"JSESSIONID": jid}).text


@app.get("/reg")
def reg(mcode, cnt, classno, bookid):
    reservation(mcode, cnt, classno, bookid)
    return HTMLResponse(f'<meta http-equiv=Refresh content=0;url="{host}:{port}/std">')
